﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPMailApplication
{
    public interface IMailView
    {
        string Username { get; set; }
        string password { get; set; }
        string To { get; set; }
        string subject { get; set; }
        string body { get; set; }
        string MessageSuccess();
    }
}
