﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MVPMailApplication
{
    public partial class Form1 : Form,IMailView
    {
        MailModel send;
        public Form1()
        {
            InitializeComponent();
            send = new MailModel();
        }

        private void SendMail_Button_Click(object sender, EventArgs e)
        {
            
            try
            {                
                MailPresenter presenter = new MailPresenter(this, send);
                presenter.SendMailDetails();
                progressBar1.Visible = true;
            }
            catch (Exception)
            {
                MessageBox.Show("Please check internet connection and try again");
            }
        }

        public string MessageSuccess()
        {
            progressBar1.Visible = false;
            messageLabel.Visible = true;
            return messageLabel.Text = "Message has been delevered successfully";
        }

        public string Username
        {
            get
            {
                return UserNametxt.Text;
            }
            set
            {
                UserNametxt.Text = value;
            }
        }

        public string password
        {
            get
            {
                return Passwordtxt.Text;
            }
            set
            {
                Passwordtxt.Text = value;
            }
        }

        public string To
        {
            get
            {
                return Totxt.Text;
            }
            set
            {
                Totxt.Text = value;
            }
        }

        public string subject
        {
            get
            {
                return subjecttxt.Text;
            }
            set
            {
                subjecttxt.Text = value;
            }
        }

        public string body
        {
            get
            {
                return bodytxt.Text;
            }
            set
            {
                bodytxt.Text = value;
            }
        }
    }
}
