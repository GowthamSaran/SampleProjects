﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPMailApplication
{
    public interface IMailModel
    {
        void sendMail(string Username, string password, string To, string subject, string body);
    }
}
