﻿namespace MVPMailApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.SendMail_Button = new System.Windows.Forms.Button();
            this.UserName_Label = new System.Windows.Forms.Label();
            this.Password_Label = new System.Windows.Forms.Label();
            this.To_Label = new System.Windows.Forms.Label();
            this.Subject_Label = new System.Windows.Forms.Label();
            this.Body_Label = new System.Windows.Forms.Label();
            this.UserNametxt = new System.Windows.Forms.TextBox();
            this.Passwordtxt = new System.Windows.Forms.TextBox();
            this.Totxt = new System.Windows.Forms.TextBox();
            this.subjecttxt = new System.Windows.Forms.TextBox();
            this.bodytxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.messageLabel = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // SendMail_Button
            // 
            this.SendMail_Button.Location = new System.Drawing.Point(184, 391);
            this.SendMail_Button.Name = "SendMail_Button";
            this.SendMail_Button.Size = new System.Drawing.Size(75, 23);
            this.SendMail_Button.TabIndex = 0;
            this.SendMail_Button.Text = "Send Mail";
            this.SendMail_Button.UseVisualStyleBackColor = true;
            this.SendMail_Button.Click += new System.EventHandler(this.SendMail_Button_Click);
            // 
            // UserName_Label
            // 
            this.UserName_Label.AutoSize = true;
            this.UserName_Label.Location = new System.Drawing.Point(32, 37);
            this.UserName_Label.Name = "UserName_Label";
            this.UserName_Label.Size = new System.Drawing.Size(60, 13);
            this.UserName_Label.TabIndex = 1;
            this.UserName_Label.Text = "User Name";
            // 
            // Password_Label
            // 
            this.Password_Label.AutoSize = true;
            this.Password_Label.Location = new System.Drawing.Point(32, 84);
            this.Password_Label.Name = "Password_Label";
            this.Password_Label.Size = new System.Drawing.Size(53, 13);
            this.Password_Label.TabIndex = 2;
            this.Password_Label.Text = "Password";
            // 
            // To_Label
            // 
            this.To_Label.AutoSize = true;
            this.To_Label.Location = new System.Drawing.Point(32, 129);
            this.To_Label.Name = "To_Label";
            this.To_Label.Size = new System.Drawing.Size(20, 13);
            this.To_Label.TabIndex = 3;
            this.To_Label.Text = "To";
            // 
            // Subject_Label
            // 
            this.Subject_Label.AutoSize = true;
            this.Subject_Label.Location = new System.Drawing.Point(32, 176);
            this.Subject_Label.Name = "Subject_Label";
            this.Subject_Label.Size = new System.Drawing.Size(43, 13);
            this.Subject_Label.TabIndex = 4;
            this.Subject_Label.Text = "Subject";
            // 
            // Body_Label
            // 
            this.Body_Label.AutoSize = true;
            this.Body_Label.Location = new System.Drawing.Point(32, 224);
            this.Body_Label.Name = "Body_Label";
            this.Body_Label.Size = new System.Drawing.Size(31, 13);
            this.Body_Label.TabIndex = 5;
            this.Body_Label.Text = "Body";
            // 
            // UserNametxt
            // 
            this.UserNametxt.Location = new System.Drawing.Point(184, 30);
            this.UserNametxt.Name = "UserNametxt";
            this.UserNametxt.Size = new System.Drawing.Size(100, 20);
            this.UserNametxt.TabIndex = 6;
            // 
            // Passwordtxt
            // 
            this.Passwordtxt.Location = new System.Drawing.Point(184, 77);
            this.Passwordtxt.Name = "Passwordtxt";
            this.Passwordtxt.PasswordChar = '*';
            this.Passwordtxt.Size = new System.Drawing.Size(100, 20);
            this.Passwordtxt.TabIndex = 7;
            // 
            // Totxt
            // 
            this.Totxt.Location = new System.Drawing.Point(184, 122);
            this.Totxt.Name = "Totxt";
            this.Totxt.Size = new System.Drawing.Size(100, 20);
            this.Totxt.TabIndex = 8;
            // 
            // subjecttxt
            // 
            this.subjecttxt.Location = new System.Drawing.Point(184, 169);
            this.subjecttxt.Name = "subjecttxt";
            this.subjecttxt.Size = new System.Drawing.Size(100, 20);
            this.subjecttxt.TabIndex = 9;
            // 
            // bodytxt
            // 
            this.bodytxt.Location = new System.Drawing.Point(184, 217);
            this.bodytxt.Multiline = true;
            this.bodytxt.Name = "bodytxt";
            this.bodytxt.Size = new System.Drawing.Size(455, 146);
            this.bodytxt.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(338, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Provide your gmail user name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(338, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Provide your gmail password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(290, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(290, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "*";
            // 
            // messageLabel
            // 
            this.messageLabel.AutoSize = true;
            this.messageLabel.Location = new System.Drawing.Point(181, 458);
            this.messageLabel.Name = "messageLabel";
            this.messageLabel.Size = new System.Drawing.Size(35, 13);
            this.messageLabel.TabIndex = 15;
            this.messageLabel.Text = "label5";
            this.messageLabel.Visible = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(184, 436);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(455, 10);
            this.progressBar1.TabIndex = 16;
            this.progressBar1.Value = 100;
            this.progressBar1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 480);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.messageLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bodytxt);
            this.Controls.Add(this.subjecttxt);
            this.Controls.Add(this.Totxt);
            this.Controls.Add(this.Passwordtxt);
            this.Controls.Add(this.UserNametxt);
            this.Controls.Add(this.Body_Label);
            this.Controls.Add(this.Subject_Label);
            this.Controls.Add(this.To_Label);
            this.Controls.Add(this.Password_Label);
            this.Controls.Add(this.UserName_Label);
            this.Controls.Add(this.SendMail_Button);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Eagle Mail";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SendMail_Button;
        private System.Windows.Forms.Label UserName_Label;
        private System.Windows.Forms.Label Password_Label;
        private System.Windows.Forms.Label To_Label;
        private System.Windows.Forms.Label Subject_Label;
        private System.Windows.Forms.Label Body_Label;
        private System.Windows.Forms.TextBox UserNametxt;
        private System.Windows.Forms.TextBox Passwordtxt;
        private System.Windows.Forms.TextBox Totxt;
        private System.Windows.Forms.TextBox subjecttxt;
        private System.Windows.Forms.TextBox bodytxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label messageLabel;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}

