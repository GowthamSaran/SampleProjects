﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPMailApplication
{
    public class MailPresenter
    {
        IMailModel sendData;
        IMailView UserData;
        Form1 msg;
        public MailPresenter(IMailView Data,IMailModel Send)
        {
            UserData = Data;
            sendData = Send;
        }

        public void SendMailDetails()
        {
            sendData.sendMail(UserData.Username, UserData.password, UserData.To, UserData.subject, UserData.body);
            UserData.MessageSuccess();
        }
    }
}
