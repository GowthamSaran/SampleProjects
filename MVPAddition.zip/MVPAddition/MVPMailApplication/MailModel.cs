﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Mail;

namespace MVPMailApplication
{
    public class MailModel:IMailModel
    {
        public MailModel()
        {      
        }

        public void sendMail(string Username, string password, string To, string subject, string body)
        {
            
            NetworkCredential input = new NetworkCredential(Username, password);
            MailMessage message = new MailMessage();
            message.To.Add(To);
            message.From = new MailAddress("gowtham.gunnam@whishworks.com", "Gowtham Saran Gunnam", Encoding.Unicode);
            message.Subject = subject;
            message.Body = body;
            SmtpClient client = new SmtpClient("smtp.gmail.com", 25);
            client.Credentials = input;
            client.EnableSsl = true;
            client.Send(message);
            
            
        }
    }
}
