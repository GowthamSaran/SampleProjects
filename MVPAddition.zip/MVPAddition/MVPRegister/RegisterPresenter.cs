﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPRegister
{
    public class RegisterPresenter
    {
        IRegisterView RegisterView;
        IRegisterModel RegisterModel;
        
        private MVPRegister.RegisterModel Model;
        private IRegisterView DataView;
                

        public RegisterPresenter(IRegisterView DataView, MVPRegister.RegisterModel Model)
        {
            // TODO: Complete member initialization
            this.DataView = DataView;
            this.Model = Model;
        }
        
        public void Registerpresenter(IRegisterView View,IRegisterModel Model)
        {
            RegisterView = View;
            RegisterModel = Model;
        }

        public void RegisterUser()
        {
            RegisterModel.SaveUserRegistration(RegisterView.GetName(), RegisterView.GetUserName(), RegisterView.GetPassword(), RegisterView.GetConfirmPassword());
        }
    }
}
