﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPRegister
{
    public interface IRegisterModel
    {
        void SaveUserRegistration(String Name, String UserName, String Password, String ConfirmPassword);
    }
}
