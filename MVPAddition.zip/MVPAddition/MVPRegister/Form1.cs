﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MVPRegister
{
    public partial class Form1 : Form,IRegisterView
    {
        RegisterModel Model;
        IRegisterView DataView;
        public Form1()
        {
            InitializeComponent();
            button1.Click += new EventHandler(button1_Click);
            Model = new RegisterModel();            
        }
        
        void button1_Click(object sender, EventArgs e)
        {
            RegisterPresenter presenter = new RegisterPresenter(DataView,Model);
            presenter.RegisterUser();
        }


        public string GetName()
        {
            return textBox1.Text;
        }

        public void SetName(string Name)
        {
            textBox1.Text = Name;
        }

        public string GetUserName()
        {
            return textBox2.Text;
        }

        public void SetUserName(string UserName)
        {
            textBox2.Text = UserName;
        }

        public string GetPassword()
        {
            return textBox3.Text;
        }

        public void SetPassword(string Password)
        {
            textBox3.Text = Password;
        }

        public string GetConfirmPassword()
        {
            return textBox4.Text;
        }

        public void SetConfirmPassword(string ConfirmPassword)
        {
            textBox4.Text = ConfirmPassword;
        }
    }
}
