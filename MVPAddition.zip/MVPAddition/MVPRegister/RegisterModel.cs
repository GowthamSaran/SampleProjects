﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPRegister
{
    public class RegisterModel:IRegisterModel
    {
        

        public void SaveUserRegistration(string Name, string UserName, string Password, string ConfirmPassword)
        {
            MVPRegisterDataContext DataBase = new MVPRegisterDataContext();
            MVPRegister_Sample Table = new MVPRegister_Sample();
            Table.Name = Name;
            Table.User_Name = UserName;
            Table.Password = Password;
            Table.Confirm_Password = ConfirmPassword;
            DataBase.MVPRegister_Samples.InsertOnSubmit(Table);
            DataBase.SubmitChanges();
        }
    }
}
