﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPRegister
{
    public interface IRegisterView
    {
        /// <summary>
        /// Reads Name from user
        /// </summary>
        /// <returns></returns>
        String GetName();

        /// <summary>
        /// sets the Name
        /// </summary>
        void SetName(String Name);

        /// <summary>
        /// Reads the userName from the textbox
        /// </summary>
        /// <returns></returns>
        String GetUserName();

        /// <summary>
        /// Sets the userName
        /// </summary>
        void SetUserName(String UserName);

        /// <summary>
        /// Reads the user Input
        /// </summary>
        /// <returns></returns>
        String GetPassword();

        /// <summary>
        /// Set the password
        /// </summary>
        /// <param name="Password"></param>
        void SetPassword(String Password);

        /// <summary>
        /// Reads the user input
        /// </summary>
        /// <returns></returns>
        String GetConfirmPassword();

        /// <summary>
        /// It will sets the password
        /// </summary>
        /// <param name="ConfirmPassword"></param>
        void SetConfirmPassword(String ConfirmPassword);

    }
}
