﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MVPLoginWithDatabase
{
    public partial class Form1 : Form,ILoginView
    {
        LoginModel Model;
        public Form1()
        {
            InitializeComponent();
            Model = new LoginModel();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginPresenter presenter = new LoginPresenter(this,Model);
            presenter.MediateUserData();
        }

        public string UserName
        {
            get
            {
                return txtUserName.Text;
            }
            set
            {
                txtUserName.Text = value;
            }
        }

        public string Password
        {
            get
            {
                return txtPassword.Text;
            }
            set
            {
                txtPassword.Text = value;
            }
        }

        public bool CheckBoxChecked
        {
            get
            {
                return checkBox1.Checked;
            }
            set
            {
                checkBox1.Checked = value;
            }
        }
    }
}
