﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPLoginWithDatabase
{
    public interface ILoginView
    {
        string UserName { get; set; }
        string Password { get; set; }
        bool CheckBoxChecked { get; set; }
    }
}
