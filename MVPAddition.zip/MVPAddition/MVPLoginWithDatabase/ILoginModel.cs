﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPLoginWithDatabase
{
    public interface ILoginModel
    {
        void GetUserData(string UserName, string Password, bool CheckBoxChecked);
    }
}
