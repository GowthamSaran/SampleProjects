﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPLoginWithDatabase
{
    public class LoginPresenter
    {
        ILoginView view;
        ILoginModel model;
        
        public   LoginPresenter(ILoginView LoginViewData,ILoginModel LoginModelData)
        {
            view = LoginViewData;
            model = LoginModelData;
        }

        public void MediateUserData()
        {
            model.GetUserData(view.UserName, view.Password, view.CheckBoxChecked);
        }
    }
}
