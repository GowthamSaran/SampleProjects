﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Web;


namespace MVPLoginWithDatabase
{
    public class LoginModel:ILoginModel
    {
        public   LoginModel()
        {
        }
        public void GetUserData(string UserName, string Password, bool CheckBoxChecked)
        {
            
            
            
            MVPLoginLinqDataContext sample = new MVPLoginLinqDataContext();
            MVPLogin_Sample MVPLogin = new MVPLogin_Sample();
            MVPLogin.User_Name = UserName;
            MVPLogin.Password = Password;
            sample.MVPLogin_Samples.InsertOnSubmit(MVPLogin);
            sample.SubmitChanges();


            XmlWriter write = XmlWriter.Create(@"c:\LoginData.xml");
            write.WriteStartDocument();
            write.WriteStartElement("LoginDetails");
            write.WriteStartElement("UserName");
            write.WriteString(UserName);
            write.WriteEndElement();

            write.WriteStartElement("Password");
            write.WriteString(Password);
            write.WriteEndElement();

            write.WriteStartElement("CheckBox");
            if (CheckBoxChecked)
            {
                write.WriteValue(CheckBoxChecked);
            }
            else
            {
                write.WriteValue("false");
            }
            write.WriteEndElement();
            write.Close();
        }
    }
}
