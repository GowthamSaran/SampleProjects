﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPAddition
{
    public interface IAdditionView
    {
        int a { get; set; }
        int b { get; set; }
        void SetSumvalue(int sumval);
    }
}
