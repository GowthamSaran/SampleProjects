﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace MVPAddition
{
    public partial class Form1 : Form, IAdditionView
    {
        AdditionModel model;
        public Form1()
        {
            InitializeComponent();
            model = new AdditionModel();
            this.textBox1.Text = model.DefautlA().ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                AdditionPresenter Presenter = new AdditionPresenter(this, model);
                Presenter.AddTwoNumbers();
                
            }
            catch (Exception)
            {
                Regex rx = new Regex("[^/D]");
                if (rx.IsMatch(textBox1.Text))
                {
                    MessageBox.Show("Congragulations! You have not entered numeric values in the textbox");
                }
                else
                {
                    MessageBox.Show("Please provide me the values i can calculate i.e, less than 1000000000 and greater than 0");
                }
                
            }

        }



        int IAdditionView.a
        {
            get { return int.Parse(textBox1.Text); }
            set { textBox1.Text = value.ToString(); }
        }

        int IAdditionView.b
        {
            get { return int.Parse(textBox2.Text); }
            set { textBox2.Text = value.ToString(); }
        }

        void IAdditionView.SetSumvalue(int sumval)
        {
            label3.Text = sumval.ToString();
            label3.Visible = true;
        }
    }
}
