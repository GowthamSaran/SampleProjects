﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPAddition
{
    public class AdditionPresenter
    {
        IAdditionView AddView;
        IAdditionModel AddModel;
        public AdditionPresenter(IAdditionView AdditionView,IAdditionModel addModel)
        {
            AddView = AdditionView;
            AddModel = addModel;
        }

        public void AddTwoNumbers()
        {            
            AddView.SetSumvalue(AddModel.getResult(AddView.a, AddView.b));
        }
    }
}
