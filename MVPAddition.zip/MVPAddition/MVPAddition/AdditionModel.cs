﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPAddition
{
    class AdditionModel:IAdditionModel
    {
        public int getResult(int a, int b)
        {
            return a + b;            
        }

        public int DefautlA()
        {
            return 10;
        }        
    }
}
