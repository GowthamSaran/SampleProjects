﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVPAddition
{
    public interface IAdditionModel
    {
        int DefautlA();
        int getResult(int a,int b);        
    }
}
