
public class JavaHW1 {
	public static void main(String[] args)
	{
		JavaHW1 arrays = new JavaHW1();
		
		char ar1[] = {'a','A','B'};
		char ar2[] = {'A','a','b'};
		
		boolean charArrayEqual = arrays.equalsIgnoreCase(ar1,3,ar2,3);
		
		if(charArrayEqual)
			System.out.println("Returning true as both arrays has the same the same data, irrespective of the case.");
		else
			System.out.println("The data in both arrays doesn't have the same data.");		
	}

	private boolean equalsIgnoreCase(char[] ar1, int ar1Size, char[] ar2, int ar2Size) {
		// TODO Auto-generated method stub
		if(ar1Size!=ar2Size)
		{
			return false;
		}
		else
		{
			for(int i=0;i<ar1Size;i++)
			{
				if(Character.toUpperCase(ar1[i])!=Character.toUpperCase((ar2[i])))
						{
							return false;
						}
			}			
		}
		return true;
		
	}

}
