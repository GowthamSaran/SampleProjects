import java.util.Scanner;


public class JavaHW1_Program1 {
	public static void main(String[] args)	
	    {
		int weightOftheOrder;  
        double shippingCost;  
        Scanner readInput = new Scanner(System.in);  
        System.out.println("Weight of order : ");  
        weightOftheOrder = readInput.nextInt();  
        while(weightOftheOrder > 0)  
        {  
            if(weightOftheOrder <= 10)            
            	shippingCost = 3.00;              
            else                            
            	shippingCost = 3.00 + ((weightOftheOrder - 10) * 0.25);  
            System.out.println("Shipping cost is : $" + shippingCost);  
            System.out.println("Weight of order is : ");  
            weightOftheOrder = readInput.nextInt();  
        }
        	System.out.println("bye.....");			
	    }
}
