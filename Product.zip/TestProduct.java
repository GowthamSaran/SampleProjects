
public class TestProduct {
	public static void main(String[] args)
	{
		//program 1 & 2
		Product objProduct1 = new Product();
		objProduct1.discount(95);		
		show(objProduct1);		
		
		Product objProduct2 = new Product("Test",1000);
		objProduct2.discount(25);
		show("\n"+objProduct2);		
				
		//program 3
		Tablet objTablet1 = new Tablet();
		modelChecker(objTablet1.model);
		show(objTablet1);
				
		Tablet objTablet2 = new Tablet(20,2);
		modelChecker(objTablet2.model);
		show(objTablet2);
				
		Tablet objTablet3 = new Tablet("Samsung",900,12,3);
		modelChecker(objTablet3.model);
		show(objTablet3);
				
		//program 4
		Tablet t1 = new Tablet();
		modelChecker(t1.model);
		show(t1.toString());
		
		Tablet t2 = new Tablet(8.5,2);
		modelChecker(t2.model);
		show(t2.toString());
		
		Tablet t3=new Tablet("Samsung",900,12,3);
		modelChecker(t3.model);
		show(t3.toString());
		
		double varDiscount = t3.discount(18.5);
		show("\nDiscount price is :"+varDiscount);
	}
	
	//program 5 **printer method that is used to print every thing on output
	public static void show(Object objParms)
	{		
		System.out.println(objParms.toString());		
	}	
	
	//this method checks the model
	public static void modelChecker(int mdl)
	{
		if(mdl==1)
			System.out.println("\nModel is : A-100");
		if(mdl==2)
			System.out.println("\nModel is : A-200");
		if(mdl==3)
			System.out.println("\nModel is : A-500");		
	}

}
