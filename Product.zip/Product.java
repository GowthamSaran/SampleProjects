import java.util.Date;
//program 1 & 2
public class Product {
	protected String brand;
	protected double price;
	protected double updatedPrice;
	protected Date createDate=new Date();
	Product()
	{
		brand = "NPU";
		price=500;				
	}
	
	Product(String brand1,double price1)
	{
		this.brand = brand1;
		this.price = price1;
	}
	
	public String toString()
	{
		return "Brand Name is "+this.brand+ "\n"+"Price is :"+this.price+"\n"+"Created date :"+createDate.toString()+"\nDiscount price is : "+updatedPrice;
		
	}
	
	public double discount(double percentOff)
	{		
		updatedPrice = price*((100-percentOff)/100);
		return updatedPrice;
	}

}
