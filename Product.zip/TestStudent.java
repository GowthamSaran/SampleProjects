
public class TestStudent {
	public static void main(String[] args)
	{
		Student objStudent1=new Student();
		Student objStudent2=new Student("Gowtham","Saran",14085);
		objStudent2.setQuizscores(0,49);
		objStudent2.setQuizscores(1,45);
		objStudent2.setQuizscores(2,43.2);
		objStudent2.setQuizscores(3,49.1);
		objStudent2.setQuizscores(4,46);
		objStudent2.printStudent();		
	}	
}