//program 3
public class Tablet extends Product{
	protected double screenSize;
	protected int model;	
		
	Tablet()
	{
		screenSize = 10;
		model = 1;
	}
	
	Tablet(double screenSize1,int model1)
	{
		this.screenSize = screenSize1;
		this.model = model1;
	}
	
	Tablet(String brand2,double price2, double screenSize2,int model2)
	{
		this.brand = brand2;
		this.price = price2;
		this.screenSize = screenSize2;
		this.model = model2;
	}
	
	public String toString()
	{
		return "Brand Name is :"+brand+ "\n"+"Price is :"+price+"\n"+"Screen size is :"+screenSize;
	}
}
