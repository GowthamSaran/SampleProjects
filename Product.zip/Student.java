
public class Student {
	private static String firstName;
	private static String lastName;
	private static int id;
	private static double[] quizscores={0,1,2,3,4};
	static int Studentcount;
	
	Student() {
		firstName = "John";
		lastName = "Doe";
		System.out.println("Initial data :"+"\n"+ "First name : "+firstName+ "\n"+"Last Name " + lastName);
		System.out.println("After changes to the above data :"+"\n"+"First Name :"+setLastName("Fremont") +"\n"+"ID is :"+setId(007));
		
	}
	
	Student(String firstname,String lastname,int id)
	{
		setFirstName(firstname);
		setLastName(lastname);
		setId(id);
		Studentcount++;
	}
	
	public static void printStudent() {
		
		firstName =setFirstName("Gowtham");
		lastName = setLastName("Saran");
		//id = setId(10);
		System.out.println("Name : " + firstName+ " " + lastName);
		System.out.println("ID Number is : "+getId());
		printScores();
		System.out.println("Total Students :" + Student.Studentcount);
		
	}

	public static String getFirstName() {
		return firstName;
	}

	public static String setFirstName(String firstName) {
		Student.firstName = firstName;
		return Student.firstName; 
	}

	public static String getLastName() {
		return lastName;
	}
	
	public static double[] getQuizscores() {
		return quizscores;
	}
	
	public static void setQuizscores(int QuizNum, double Quizscores) 
	{
		quizscores[QuizNum] = Quizscores;
	}
	
	public static void printScores(){
		 System.out.println("Quiz Scores are :");
		 for(int i = 0; i <=4; i++)
			 System.out.println(quizscores[i]);
	}

	public static String setLastName(String lastName) {
		Student.lastName = lastName;
		return Student.lastName; 
	}

	public static int getId() {
		return id;
	}

	public static int setId(int id) {
		Student.id = id;
		return Student.id; 
	}
}