import java.util.Scanner;


public class Week2Example1 {
	public static void main(String[] args)
	{
		double InvestmentAmount;
		double AnnualInterest;
		int NumberOfYears;
		double FutureInvestmentValue;
		
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter Investment Amount : ");
		InvestmentAmount = in.nextDouble();
		
		System.out.println("Enter Annual Interest : ");
		AnnualInterest = in.nextDouble();
		
		System.out.println("Enter Number of years : ");
		NumberOfYears = in.nextInt();
		System.out.println("Future investment value is : " + Math.pow(InvestmentAmount*(1+(AnnualInterest/100)), NumberOfYears));
		
	}

}

//FutureInvestmentValue = (InvestmentAmoutn * (1+(AnnualInterestRate/100)))NumberOfYears
