import java.util.Scanner;


public class ValidateMultiplicationResult {
	public static void main(String[] args)
	{
		int MultiplicationResult;
		double EnterAnswer;
		int A;
		int B;
		int Result;
		A = (int)(Math.random()*10);
		B = (int)(Math.random()*10);
		Result = A * B;
		System.out.println("What is " + A + "*" + B);
		Scanner input = new Scanner(System.in);
		EnterAnswer = input.nextDouble();
		if(EnterAnswer == Result)
			System.out.println("The value entered is correct");
		else
			System.out.println("The value entered by you is incorrect. It should be " + Result);		
	}
}
