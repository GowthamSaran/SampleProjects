import java.util.Scanner;


public class Week2Example4 {
	public static void main(String[] args)
	{
		System.out.println("Enter Year to check if it Leap year or not : ");
        int year;
        Scanner in = new Scanner(System.in);
        year = in.nextInt();

        if ((year % 4 == 0) && year % 100 != 0)
        {
        	System.out.println(year + " is a leap year.");
        }
        else if ((year % 4 == 0) && (year % 100 == 0) && (year % 400 == 0))
        {
        	System.out.println(year + " is a leap year.");
        }
        else
        {
            System.out.println(year + " is not a leap year.");
        }
	}

}
