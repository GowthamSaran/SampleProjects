import java.util.Scanner;


public class HoursConversion {
	public static void main(String[] args)
	{
		System.out.print("Please enter the number of Days: ");		
		Scanner input = new Scanner(System.in);
		int EnteredNumber = input.nextInt();	
		int numberofhours = EnteredNumber * 24;
		int abovehours = EnteredNumber *1440;
		System.out.println("Number of hours per " + EnteredNumber + " day(s) is " + numberofhours + " and " + abovehours + " minutes" );

	}

}
