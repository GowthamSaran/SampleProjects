import java.util.Scanner;


public class Week2Example3 {
	public static void main(String[] args)
	{
		String YourName;
		System.out.println("Enter your Name : ");
		Scanner in = new Scanner(System.in);
		YourName = in.next();
		System.out.println("Welcome " + YourName);
		
	}

}
