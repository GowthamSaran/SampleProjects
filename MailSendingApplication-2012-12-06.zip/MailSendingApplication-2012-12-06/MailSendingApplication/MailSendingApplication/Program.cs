﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Mail;

namespace MailSendingApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            NetworkCredential input = new NetworkCredential("saran.gunnam@gmail.com", "");
            MailMessage message = new MailMessage();
            message.To.Add("vennamadhukarreddy@gmail.com");
            message.From = new MailAddress("saran.gunnam@gmail.com", "Gowtham Saran Gunnam", Encoding.Unicode);
            message.Subject = "Test Email";
            message.Body="Hi Madhukar";
            SmtpClient client = new SmtpClient("smtp.gmail.com", 25);
            client.Credentials = input;
            client.EnableSsl = true;
            client.Send(message);


        }
    }
}
