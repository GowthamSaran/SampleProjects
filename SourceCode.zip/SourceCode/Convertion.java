
public class Convertion {
	
	public static double inchToCentimeter(double value2){
		value2 = (2.54 * value2);
		return value2;	    
	}
		
	
	public static double mileToKilometer(double value2){
	        value2 = 1.61 * value2;
	        return value2;	        
	}
	
	public static double poundToKilogram(double value2){	        
	        value2 = 0.454 * value2;
	        return value2;	        
	}
	
	public static double celsiusToFahrenheit(double value2){
	        
	        double Fahrenheit;
	        Fahrenheit = (value2*(9/5))+32;
	        return Fahrenheit;	
	}
}

