import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class LabExercise12 extends JFrame implements ActionListener,
		ChangeListener, ItemListener {
	private int size = 50;

	Color currentColor;

	int radioButtonCmd;

	private DrawingPanel drawingPanel = new DrawingPanel();

	JPanel sliderPanel = new JPanel();

	JPanel radiobtnPanel = new JPanel();

	JPanel comboPanel = new JPanel();

	JSlider objSlider = new JSlider();

	String colors[] = { "Black", "Blue", "Red" };

	JRadioButton rbtnCircle = new JRadioButton("Circle");

	JRadioButton rbtnSquare = new JRadioButton("Square");

	ButtonGroup grpButtons = new ButtonGroup();

	JComboBox combobox = new JComboBox(colors);

	public LabExercise12() {

		setLayout(new GridLayout(4, 2));
		// adding circle
		add(drawingPanel, BorderLayout.CENTER);

		drawingPanel.setLayout(new GridLayout());

		// adding slider

		objSlider.setLayout(new GridLayout());

		sliderPanel.add(objSlider);

		add(sliderPanel, BorderLayout.SOUTH);

		objSlider.setPaintTicks(true);

		objSlider.setMaximum(100);

		objSlider.setMinorTickSpacing(2);

		objSlider.setMajorTickSpacing(10);

		objSlider.setPaintLabels(true);

		// adding radio buttons

		radiobtnPanel.setLayout(new GridLayout());

		grpButtons.add(rbtnCircle);

		grpButtons.add(rbtnSquare);

		radiobtnPanel.add(rbtnCircle);

		radiobtnPanel.add(rbtnSquare);

		add(radiobtnPanel, BorderLayout.SOUTH);

		add(radiobtnPanel, BorderLayout.SOUTH);

		// adding combobox

		comboPanel.add(combobox);

		comboPanel.setLayout(new GridLayout());

		add(comboPanel, BorderLayout.SOUTH);

		rbtnCircle.addActionListener(this);

		rbtnSquare.addActionListener(this);

		objSlider.addChangeListener(this);

		objSlider.setPreferredSize(null);

		combobox.addItemListener(this);

	}

	class DrawingPanel extends JPanel {
		private int x;
		private int y;

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			x = (this.getWidth() - size) / 2;
			y = (this.getHeight() - size) / 2;

			if (radioButtonCmd == 1) {
				g.setColor(currentColor);
				g.fillOval(x, y, size, size);
			}

			else {
				g.setColor(currentColor);
				g.fillRect(x, y, size, size);
			}

		}
	}

	public static void main(String[] args) {
		LabExercise12 frame = new LabExercise12();
		frame.setSize(300, 280);
		frame.setTitle("Lab Exercise 12");
		frame.setLocationRelativeTo(null); // Center the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent argAction) {
		// TODO Auto-generated method stub

		String action = argAction.getActionCommand();

		if (action == "Circle") {
			radioButtonCmd = 1;
		}

		else {
			radioButtonCmd = 2;
		}

		repaint();

	}

	@Override
	public void stateChanged(ChangeEvent arg0) {
		// TODO Auto-generated method stub
		size = Math.min(getWidth(), getHeight()) * objSlider.getValue()
				/ objSlider.getMaximum();
		repaint();

	}

	@Override
	public void itemStateChanged(ItemEvent event) {
		// TODO Auto-generated method stub

		int itemslctd = combobox.getSelectedIndex();
		if (itemslctd == 0) {
			currentColor = Color.BLACK;
		}

		if (itemslctd == 1) {
			currentColor = Color.BLUE;
		}

		if (itemslctd == 2) {
			currentColor = Color.RED;
		}
		repaint();
	}
}
