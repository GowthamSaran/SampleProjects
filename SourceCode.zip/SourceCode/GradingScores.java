import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;








public class GradingScores {	

	public static void main(String [] a) //throws IOException 
	{
		
		Scanner input=null;
		try {			
				DataInputStream inputData=new DataInputStream(new FileInputStream("D:\\MS\\New folder (2)\\average.dat"));
				input=new Scanner(inputData);			
				 
				while(inputData.available()!=0)
				//while(!inputData)
					{
						String fname=inputData.readUTF();
					
						String lname=inputData.readUTF();
					
						double average=inputData.readDouble();
						
						gradeChecker(average,fname,lname);
						
						
					}
				System.out.println("End of file");
				
				}
				catch(IOException exe)
					{
						System.out.println("Error is : "+exe);
					}
			}
	
	public static  void gradeChecker(double average1, String fname1, String lname1) {
		// TODO Auto-generated method stub
		if(average1>45.0)
		{
			System.out.println(fname1+" "+lname1+" Average:"+average1+" GRADE=A");
		    
		}
		else if(average1>=40)
		{
			System.out.println(fname1+" "+lname1+" Average:"+average1+" Grade=B");
		}
		else if(average1>=35)
		{
			System.out.println(fname1+" "+lname1+" Average:"+average1+" Grade=C");
		}
		else if(average1>=30)
		{
			System.out.println(fname1+" "+lname1+" Average:"+average1+" Grade=D");
		}
		
	}

}	