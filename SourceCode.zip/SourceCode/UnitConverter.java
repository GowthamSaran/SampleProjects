import java.util.Scanner;


public class UnitConverter {
	public static void main(String[] args) {
        // TODO Auto-generated method stub
		//double value2=0;
        System.out.println("Enter a value to check the convertion result :");
        Scanner input = new Scanner(System.in);
        double value1 = input.nextInt();
        System.out.println(value1 + " inchs =" + Convertion.inchToCentimeter(value1)+" centimeters");
        System.out.println(value1 + " miles =" + Convertion.mileToKilometer(value1)+" kilometers");
        System.out.println(value1 + " pound =" + Convertion.poundToKilogram(value1)+" kilogram");
        System.out.println(value1 + " celsius =" + Convertion.celsiusToFahrenheit(value1)+" fahrenheit");
}
           

}
