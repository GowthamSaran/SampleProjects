import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;


public class AnalyzeScores{
	public static void main(String [] args) throws IOException 
	{	
		int [] scores=new int[5];  
		Scanner	inputFile=null;
		double additionResult=0;

		try 
		{
			FileInputStream outputWriter = new FileInputStream(new File("D:\\MS\\New folder (2)\\scores2.txt"));
			
			DataOutputStream fileWriter=new DataOutputStream(new FileOutputStream("D:\\MS\\New folder (2)\\average.dat"));
			inputFile= new Scanner(outputWriter);
			     while( inputFile.hasNext())
			     {
					String fname=inputFile.next();	
					fileWriter.writeUTF(fname);
					String lname=inputFile.next();
					fileWriter.writeUTF(lname);
					System.out.println(fname+" "+lname);					
					additionResult=0;
					for(int i=0;i<=scores.length -1;i++)
						{
							scores[i]=inputFile.nextInt();
							additionResult=additionResult+scores[i];
							System.out.println(additionResult);
							System.out.println(scores[i]);
	                    }
				      double average=additionResult/scores.length;
				      System.out.println("Average : "+average);
				      fileWriter.writeDouble(average);
				      
			     }			
		}
		catch(FileNotFoundException exe)
		{				
			exe.printStackTrace();
		}		
	}

}