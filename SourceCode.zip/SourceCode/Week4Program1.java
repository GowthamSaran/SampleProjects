import java.util.Scanner;

public class Week4Program1 {
	public static void main(String[] args)
	{		
		int readValues;
		int[] userInput =new int[5];
		
		for (int i= 0; i<userInput.length; i++)
         {
			System.out.println("Enter integer "+i);
			Scanner in=new Scanner(System.in);
			int value1 = in.nextInt();
			userInput[i] = value1;
         }
		printArray(userInput); //Program 1 to print array
		reverseArray(userInput); // program 2 to print array in reverse order
		findEvenNumbersInArray(userInput); //Program 3 to dnt in display even number count in the array
	}
	
	private static void findEvenNumbersInArray(int[] userInput) {
		// TODO Auto-generated method stub
		System.out.println("Now printing the even number count in the entered array");
		int evenNumbers=0;
		for(int i=0; i<userInput.length;i++)
		{
			if (userInput[i] % 2 == 0) {
				evenNumbers+=1;
			}
		}
		System.out.println("Total even numbers in the array are "+evenNumbers);
		
	}

	private static void reverseArray(int[] userInput) {
		// TODO Auto-generated method stub
		System.out.println("After the Reverse of Original Array Values :");
        
        for(int reverseList=userInput.length-1; reverseList >= 1;reverseList--)
          	System.out.println(userInput[reverseList]);
                
        if(userInput.length>=5)
        	System.out.println( "and " +userInput[0]);		
	}

	public static void printArray(int[] userInputArgs)
	{
		System.out.println("Original Array Values are :");
        for(int i= 0; i<userInputArgs.length-1; i++){        	
                	System.out.println(userInputArgs[i]);                	
        }
        if(userInputArgs.length<=5)
        	System.out.println( "and " +userInputArgs[4]);
	}
}