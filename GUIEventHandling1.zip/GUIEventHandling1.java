package Week14;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Ellipse2D;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.SliderUI;

public class GUIEventHandling1 extends JFrame implements KeyListener,
		ChangeListener {

	private int size = 50;
	private static Ellipse2D.Double circle;
	private int shape = 0;
	Color currentColor;

	int positionX = 0;
	int positionY = 0;
	float currentPosition;
	// private String[] colors = { "Black", "Blue", "Red" };

	private DrawingPanel drawingPanel = new DrawingPanel();
	private JSlider jsldHort = new JSlider(JSlider.HORIZONTAL, 0, 255, 0);
	// private JComboBox jcbColors = new JComboBox(colors);
	JTextField txtColor = new JTextField();

	public GUIEventHandling1() {
		JPanel pComp = new JPanel(new GridLayout(2, 1, 5, 5));

		add(drawingPanel, BorderLayout.CENTER);
		add(pComp, BorderLayout.SOUTH);

		// Set properties for slider
		jsldHort.setMaximum(100);
		jsldHort.setPaintLabels(true);
		jsldHort.setPaintTicks(true);
		jsldHort.setMajorTickSpacing(10);
		jsldHort.setMinorTickSpacing(2);
		jsldHort.setPaintTrack(false);
		jsldHort.setValue(50);

		// Register listener for the slider
		jsldHort.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {

				repaint();

			}
		});

		pComp.add(jsldHort);

		pComp.add(txtColor);

		txtColor.addKeyListener(this);

	}

	class DrawingPanel extends JPanel {
		private int x = -1;
		private int y = -1;

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.setColor(currentColor);

			x = (this.getWidth() / 100 * jsldHort.getValue());
			y = (this.getHeight()) / 2;

			g.fillOval(x, y, size, size);

		}
	}

	public static void main(String[] args) {
		GUIEventHandling1 frame = new GUIEventHandling1();
		frame.setSize(300, 250);
		frame.setTitle("GUI Events Handling");
		frame.setLocationRelativeTo(null); // Center the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		String color = txtColor.getText();

		String color1 = color.toLowerCase();

		if (color1.equals("red")) {
			currentColor = Color.RED;
		} else if (color1.equalsIgnoreCase("blue")) {
			currentColor = Color.BLUE;
		} else if (color1.equals("black")) {
			currentColor = Color.BLACK;
		}

		repaint();

	}

	public void updatePosition(int update) {
		positionX = update;
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void stateChanged(ChangeEvent arg0) {
		// TODO Auto-generated method stub

	}
}
