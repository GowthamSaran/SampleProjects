package JAvalab9;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Analyzescores {
	
			public static void main(String [] a) throws IOException //throws IOException 
			{	
		int [] Student1=new int[5];  
		Scanner	in=null;
		double sum=0;
		
try 
{
		     	BufferedReader f=new BufferedReader( new FileReader("D:\\Lab\\src\\java\\scores2.txt"));
				
				DataOutputStream w=new DataOutputStream(new FileOutputStream("D:\\Lab\\src\\java\\average.dat"));
				in= new Scanner(f);
					     while( in.hasNext())
					     {

	
						String fname=in.next();

						String lname=in.next();
						System.out.println(fname+" "+lname);
						w.writeUTF(fname);
						w.writeUTF(lname);
						sum=0;
						for(int i=0;i<=Student1.length -1;i++)
							{
								Student1[i]=in.nextInt();
								sum=sum+Student1[i];
								System.out.println(+Student1[i]);
	                        }
              double average=sum/Student1.length;
              System.out.println("average"+average);
              w.writeDouble((byte)average);
										
					     }				
					

					
}
				catch(FileNotFoundException e)
				    {
						System.out.println("ff cld not found");
						e.printStackTrace();
				    }
				catch(IOException e)
					{
						e.getMessage();
					}
	     }
			
	}
		





package JAvalab9;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Analyzescores {
	
			public static void main(String [] a) throws IOException //throws IOException 
			{	
		int [] Student1=new int[5];  
		Scanner	in=null;
		double sum=0;
		
try 
{
		     	BufferedReader f=new BufferedReader( new FileReader("D:\\Lab\\src\\java\\scores2.txt"));
				
				DataOutputStream w=new DataOutputStream(new FileOutputStream("D:\\Lab\\src\\java\\average.dat"));
				in= new Scanner(f);
					     while( in.hasNext())
					     {

	
						String fname=in.next();

						String lname=in.next();
						System.out.println(fname+" "+lname);
						w.writeUTF(fname);
						w.writeUTF(lname);
						sum=0;
						for(int i=0;i<=Student1.length -1;i++)
							{
								Student1[i]=in.nextInt();
								sum=sum+Student1[i];
								System.out.println(+Student1[i]);
	                        }
              double average=sum/Student1.length;
              System.out.println("average"+average);
              w.writeDouble((byte)average);
										
					     }				
					

					
}
				catch(FileNotFoundException e)
				    {
						System.out.println("ff cld not found");
						e.printStackTrace();
				    }
				catch(IOException e)
					{
						e.getMessage();
					}
	     }
			
	}
		





