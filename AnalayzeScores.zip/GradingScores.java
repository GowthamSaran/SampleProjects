package JAvalab9;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class GradingScores {
	public static void main(String [] a) throws IOException 
	{
		
	Scanner in=null;
		try {
			
			//BufferedReader f=new BufferedReader( new FileReader("D:\\Lab\\src\\java\\average.dat"));
			DataInputStream w=new DataInputStream(new FileInputStream("D:\\Lab\\src\\java\\average.dat"));
			in=new Scanner(w);
			//while( w.read()){
//string content; 
while(w.available()!=0)
{
				String fname=w.readUTF();

String lname=w.readUTF();

double average=w.readDouble();
			
	if(average>45.0)
	{
		System.out.println(fname+" "+lname+" Average:"+average+" GRADE=A");
	    
	}
	else if(average>=40)
	{
		System.out.println(fname+" "+lname+" Average:"+average+" Grade=B");
	}
	else if(average>=35)
	{
		System.out.println(fname+" "+lname+" Average:"+average+" Grade=C");
	}
	else if(average>=30)
	{
		System.out.println(fname+" "+lname+" Average:"+average+" Grade=D");
	}
}	
System.out.println("ALL DATA WERE READ");
		}
catch(IOException e)
		{
			System.out.println("input exactly");
		}
	}
}
