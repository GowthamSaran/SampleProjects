﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace SMS_LoginVer2._0
{
    public partial class Form1 : Form
    {
        public string getusername()
        {
            return UserNametextBox.Text;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string UName = "";
            string Pwd = "";
            UName = UserNametextBox.Text;
            Pwd = PasswordtextBox.Text;
            string data="";
            //GetData(UName, Pwd,data);
            string path = @"C:\SLogi.xml";
            XmlDocument doc = new XmlDocument();
            doc.Load(path);

            XmlNodeList nodes = doc.GetElementsByTagName("Login");
            for (int i = 0; i < nodes.Count; i++)
            {
                data = doc.FirstChild.InnerText;

                if (UName.Equals(data) && Pwd.Equals(data))
                {
                    
                    MessageBox.Show("Login successfull");
                }
                else
                {
                    MessageBox.Show("Login fail");
                }
            }
        }

        public string GetData(string UName,string pwd,string data)
        {
            List<LoginData> logindata = new List<LoginData>();
            return data;
        }

        public class LoginData
        {
            public string UserName { get; set; }
            public string Password { get; set; }
            public string data { get; set; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignUp form = new SignUp();
            form.Show();
        }
    }
}
