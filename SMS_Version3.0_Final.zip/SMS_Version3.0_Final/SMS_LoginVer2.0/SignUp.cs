﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace SMS_LoginVer2._0
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
            string path = @"C:\SLogi.xml";
            XmlDocument docx = new XmlDocument();            
            XmlNode Root = docx.AppendChild(docx.CreateElement("Login"));
            XmlNode node = docx.CreateNode(XmlNodeType.Element, "LoginDetails", null);
            XmlNode UserName = Root.AppendChild(docx.CreateElement("UserName"));
            //XmlAttribute attr = UserName.Attributes.Append(docx.CreateAttribute("Attribute"));
            XmlNode Password = Root.AppendChild(docx.CreateElement("Password"));
            //XmlAttribute pswattr = Password.Attributes.Append(docx.CreateAttribute("Login"));
            //attr.InnerText = "UserName";
            UserName.InnerText = "Password";
            //pswattr.InnerText = "UserName";
            Password.InnerText = "Password";
            docx.Save(path);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = @"C:\SLogi.xml";
            if (!Directory.Exists(path))
                Directory.CreateDirectory(Path.GetDirectoryName(path));

            //string filename = @"C:";

            if (File.Exists(path))
            {
                //create new instance of XmlDocument
                XmlDocument doc = new XmlDocument();

                //load from file
                doc.Load(path);

                //create node and add value
                XmlNode node = doc.CreateNode(XmlNodeType.Element, "LoginDetails", null);
                //node.InnerText = "this is new node";

                //create title node
                XmlNode nodeTitle = doc.CreateElement("UserName");
                //add value for it
                nodeTitle.InnerText = textBox1.Text;

                //create Url node
                XmlNode nodeUrl = doc.CreateElement("Password");
                nodeUrl.InnerText = textBox2.Text;

                //add to parent node
                node.AppendChild(nodeTitle);
                node.AppendChild(nodeUrl);

                //add to elements collection
                doc.DocumentElement.AppendChild(node);

                //save back
                doc.Save(path);
            }
        }
    }
}
