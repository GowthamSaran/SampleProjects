﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Xml.Linq;


namespace SMS_Version2._0
{
    public partial class AddContact : Form
    {
        public AddContact()
        {

            InitializeComponent();
        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (Name.Text == "" || Mobile.Text == "")
                {
                    label3.Text = "Please enter Name and Mobile number";
                    label3.Visible = true;
                }
                else
                {
                    string filename = @"D:\SMS_App.xml";
                    //Directory.CreateDirectory(Path.GetDirectoryName(filename));

                    ////create new instance of XmlDocument
                    //XmlDocument doc = new XmlDocument();

                    ////load from file
                    //doc.Load(filename);

                    ////create node and add value
                    //XmlNode node = doc.CreateNode(XmlNodeType.Element, "Person_Details", null);
                    ////node.InnerText = "this is new node";

                    ////create title node
                    //XmlNode nodeTitle = doc.CreateElement("Name");
                    ////add value for it
                    //nodeTitle.InnerText = Name.Text;

                    ////create Url node
                    //XmlNode nodeUrl = doc.CreateElement("MobileNumber");
                    //nodeUrl.InnerText = Mobile.Text;

                    ////add to parent node
                    //node.AppendChild(nodeTitle);
                    //node.AppendChild(nodeUrl);

                    ////add to elements collection
                    //doc.DocumentElement.AppendChild(node);

                    ////save back
                    //doc.Save(filename);

                    //label3.Text = "Contact added successfully";
                    //label3.Visible = true;

                    XmlDocument docx = new XmlDocument();

                    {
                        XmlNode root = docx.AppendChild(docx.CreateElement("person_details"));
                        XmlNode username = root.AppendChild(docx.CreateElement("name"));
                        XmlAttribute attr = username.Attributes.Append(docx.CreateAttribute("attribute"));
                        XmlNode password = root.AppendChild(docx.CreateElement("mobilenumber"));
                        XmlAttribute pswattr = password.Attributes.Append(docx.CreateAttribute("mobile_attribute"));
                        attr.InnerText = "username";
                        username.InnerText = Name.Text;
                        pswattr.InnerText = "mobilenumber";
                        password.InnerText = Mobile.Text;
                        docx.Save(@"D:\SMS_App.xml");
                    }
                    if (!File.Exists(filename))
                    {
                        XDocument doc = new XDocument(
                                       new XElement("person_details",
                                          new XElement("persondetails",
                                               new XElement("name", Name.Text),
                                               new XElement("mobilenumber", Mobile.Text)))
                                               );
                        doc.Save(filename);
                    }
                    else
                    {
                        XDocument xmldoc = XDocument.Load(filename);

                        xmldoc.Element("person_details").Add(new XElement("persondetails",
                            new XElement("name", Name.Text),
                            new XElement("mobilenumber", Mobile.Text)));

                        xmldoc.Save(filename);
                        label3.Text = "contact added successfully";
                        label3.Visible = true;
                    }
                }
            }
            catch (Exception exe)
            {
                label3.Text = exe.ToString();
                label3.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
