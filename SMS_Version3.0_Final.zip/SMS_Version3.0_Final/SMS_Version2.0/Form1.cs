﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Net;
using System.IO;

namespace SMS_Version2._0
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            SetValues();
        }

        public void SetValues()
        {
            List<DataHolder> userPhoneInfo = new List<DataHolder>();
            string path = @"D:\SMS_App.xml";
            XmlDocument docx = new XmlDocument();
            if (!File.Exists(path))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));

                //XmlDocument docx = new XmlDocument();
                XmlNode Root = docx.AppendChild(docx.CreateElement("Person_Details"));
                XmlNode UserName = Root.AppendChild(docx.CreateElement("Name"));
                XmlAttribute attr = UserName.Attributes.Append(docx.CreateAttribute("Attribute"));
                XmlNode Password = Root.AppendChild(docx.CreateElement("MobileNumber"));
                XmlAttribute pswattr = Password.Attributes.Append(docx.CreateAttribute("Mobile_Attribute"));
                attr.InnerText = "UserName";
                UserName.InnerText = "Select Recipient";
                pswattr.InnerText = "MobileNumber";
                Password.InnerText = "0000000000";
                //docx.Save(path);
            }
            else
            {
                docx.Load(path);
                XmlNodeList list = docx.GetElementsByTagName("Person_Details");
                {
                    foreach (XmlNode node in list)
                    {
                        userPhoneInfo.Add(
                            new DataHolder
                            {
                                UserName = node.ChildNodes[0].ChildNodes[0].Value.ToString(),
                                MobileNumber = node.ChildNodes[1].ChildNodes[0].Value.ToString()
                            }
                            );
                    }
                }
                List.DataSource = userPhoneInfo;
                List.DisplayMember = "UserName";
                List.ValueMember = "MobileNumber";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var myform = new AddContact();
            myform.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (UserName.Text == "" || Password.Text == "" || List.Text == "")
                {
                    MessageBox.Show("Please fill all the required(*) fields");
                }
                else
                {
                    HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create("http://ubaid.tk/sms/sms.aspx?uid=" + UserName.Text + "&pwd=" + Password.Text + "&msg=" + Body.Text + "&phone=" + List.SelectedValue + "&provider=way2sms");
                    HttpWebResponse myResp = (HttpWebResponse)myReq.GetResponse();
                    System.IO.StreamReader respStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                    string responseString = respStreamReader.ReadToEnd();
                    respStreamReader.Close();
                    myResp.Close();
                    MessageBox.Show("Hey! Your message has been delevered successfully to " + List.Text);
                    clear();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please check internet Connection and try again");
            }
        }

        private void clear()
        {
            UserName.Text = string.Empty;
            Password.Text = string.Empty;
            Body.Text = string.Empty;
            List.Text = string.Empty;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SetValues();
        }
    }

    public class DataHolder
    {
        public string UserName { get; set; }
        public string MobileNumber { get; set; }

    }
}
